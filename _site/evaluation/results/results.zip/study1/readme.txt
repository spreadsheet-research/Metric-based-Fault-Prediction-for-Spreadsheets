# Individual Metrics as Fault Predictors (Study 1)

Results are listed in files named: classifier_dataset. Every *.json file contains average and standard deviation values of the measured precision and recall over 10-fold cross validation runs for each of the predictors using one metric only.
 